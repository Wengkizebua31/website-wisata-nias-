<?php
session_start();
include 'database.php';
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container {
            max-width: 600px;
            background: rgba(255, 255, 255, 0.2);
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
        }
        .card {
            background: rgba(255, 255, 255, 0.8);
            border: none;
            color: #333;
        }
        .card:hover {
            transform: scale(1.05);
            transition: 0.3s;
        }
        .btn-danger {
            background-color: #e63946;
            border: none;
        }
        .btn-danger:hover {
            background-color: #d62828;
        }
    </style>
</head>

<body>
    <div class="container text-center">
        <h2 class="mb-4"><i class="fa-solid fa-user-shield"></i> Admin Dashboard</h2>
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h5>Selamat Datang, <b><?php echo $_SESSION['username']; ?></b></h5>
            <a href="logout.php" class="btn btn-danger"><i class="fa-solid fa-right-from-bracket"></i> Logout</a>
        </div>
        <hr class="border-white">
        
        <div class="row">
            <div class="col-md-12">
                <a href="komentar.php" class="text-decoration-none">
                    <div class="card p-3">
                        <h5><i class="fa-solid fa-comments"></i> Pesan Komentar</h5>
                        <p class="mb-0">Kelola dan lihat komentar dari pengguna.</p>
                    </div>
                </a>
            </div>
        </div>
    </div>
</body>

</html>

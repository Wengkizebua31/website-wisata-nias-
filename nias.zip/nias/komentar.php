<?php
// Pastikan path benar
include "../koneksi.php"; 

// Cek apakah koneksi tersedia
if (!isset($koneksi)) {
    die("Koneksi database tidak ditemukan.");
}

// Ambil data komentar dari database
$query = "SELECT * FROM komentar"; // Pastikan tabel ada di database
$result = $koneksi->query($query);

// Periksa apakah query berhasil
if (!$result) {
    die("Query gagal: " . $koneksi->error);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Komentar</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Daftar Komentar</h2>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Komentar</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $no = 1;
                while ($row = $result->fetch_assoc()) { ?>
                    <?php
                $no = 1;
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                            <td>{$no}</td>
                            <td>{$row['nama']}</td>
                            <td>{$row['email']}</td>
                            <td>{$row['pesan']}</td>
                          </tr>";
                    $no++;
                }
                ?>
                <?php } ?>
            </tbody>
        </table>
        <a href="index.php" class="btn btn-primary">⬅ Kembali</a>
    </div>
</body>
</html>
